import multiprocessing
import time

import pika

try:
    import ujson as json
except ImportError:
    import json

from loguru import logger

from .config import RABBITMQ_CONNECTION_URI, N_WORKERS
from .detection import *


def get_rabbit_connection():
    parameters = pika.URLParameters(RABBITMQ_CONNECTION_URI)
    while True:
        try:
            return pika.BlockingConnection(parameters=parameters)
        except pika.exceptions.AMQPConnectionError:
            time.sleep(0.2)
            continue


def event_callback(ch, method, _, body):
    decoded_body = json.loads(body)
    task_queue.put_nowait({"data": decoded_body, "delivery_tag": method.delivery_tag})


def consumer():
    channel.queue_declare(queue="recognize_photos")
    channel.basic_consume(queue="recognize_photos", on_message_callback=event_callback)
    while True:
        try:
            channel.start_consuming()
        except:  # noqa
            logger.exception('RabbitMQ error, retrying in 5 secs.')
            time.sleep(5)


def worker():
    vgg_face = get_vgg_face()
    classifier_model = get_classifier_model()
    face_detector = get_face_detector()

    while True:
        task = task_queue.get()

        try:
            image, resizing_ratio = load_image(
                image_encoded=task["data"].get("image"),
                image_url=task["data"].get("image_url"),
            )
            result = process_image(image, face_detector, classifier_model, vgg_face, resizing_ratio)

            channel.basic_publish(
                "", routing_key=task["data"]["response_queue"], body=json.dumps(result),
            )

            logger.info(
                f'Processed {task["data"]["response_queue"]} '
                f'from {"url" if task.get("url") is not None else "file"} '
                f'[resized by {round(resizing_ratio)}]'
            )

            channel.basic_ack(task["delivery_tag"])
        except:  # noqa
            logger.exception('Image processing error')


if __name__ == "__main__":
    connection = get_rabbit_connection()
    channel = connection.channel(0)
    task_queue = multiprocessing.Queue()
    for i in range(N_WORKERS):
        multiprocessing.Process(target=worker).start()
    consumer_process = multiprocessing.Process(target=consumer)
    consumer_process.start()
    consumer_process.join()
